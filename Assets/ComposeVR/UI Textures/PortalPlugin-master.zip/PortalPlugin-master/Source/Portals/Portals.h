// Released under MIT License
// Copyright (c) Pascal Krabbe 2017

#pragma once

#include "CoreMinimal.h"

//Dummy file for host project to compile plugin