// Released under MIT License
// Copyright (c) Pascal Krabbe 2017

#include "Portals.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Portals, "Portals" );

//Dummy file for host project to compile plugin